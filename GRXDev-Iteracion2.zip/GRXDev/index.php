
         <?php 
        //Incluimos el header que contiene el menu de navegación
        include 'header.php';
        //Incluimos el cuerpo
        include 'content.php';
        //Incluimos footer
        include 'footer.php'; 
        //Incluimos las ventanas modales de inicio de sesión y quienes somos
        include 'modales.php'; 
        ?>
    </body>
</html>