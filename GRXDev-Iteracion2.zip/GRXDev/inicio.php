
        <!--main-->
<div class="container" id="main">
     <div class="col-md-12 col-sm-12">
    	<div class="panel panel-default">
           <div class="panel-heading"><a href="#" class="pull-right">View all</a> <h4>Alojamientos Destacados</h4></div>
        <div class="panel-body"> 
    <div class="row">
        <?php 
        if(isset($_GET['error_sesion']))//Si existe un error de inicio de sesión se muestra el div de error
        {
        if($_GET['error_sesion'] == true){ ?>
        
        <div class="col-md-12 col-sm-12">
            <div class="alert alert-danger alert-dismissable">Error al iniciar sesi�n.</div>
        </div> 
        
        <?php }} ?>
        
     <div class="col-md-3 col-sm-6">
    	<div class="panel panel-default">
           <div class="panel-heading"><a href="#" class="pull-right">View all</a> <h4>Hotel prado</h4></div>
   			<div class="panel-body">
			  <img src="./images/h_prueba.jpg" class="img-responsive img-thumbnail pull-center" style="margin-left:5%; width:90%; height:40%;">
              <div class="clearfix"></div>
			  <hr>
              <p>The more powerful (and 100% fluid) Bootstrap 3 grid now comes in 4 sizes (or "breakpoints"). Tiny (for smartphones), Small (for tablets), Medium (for laptops) and Large (for laptops/desktops)</p>
              <div class="clearfix"></div>
              <hr>
              <div class="clearfix"></div>              
              
            </div>
         </div> 
    </div><!--/articles-->
    <div class="col-md-3 col-sm-6">
    	<div class="panel panel-default">
           <div class="panel-heading"><a href="#" class="pull-right">View all</a> <h4>Hotel prado</h4></div>
   			<div class="panel-body">
			  <img src="./images/h_prueba.jpg" class="img-responsive img-thumbnail pull-center" style="margin-left:5%; width:90%; height:40%;">
              <div class="clearfix"></div>
			  <hr>
              <p>The more powerful (and 100% fluid) Bootstrap 3 grid now comes in 4 sizes (or "breakpoints"). Tiny (for smartphones), Small (for tablets), Medium (for laptops) and Large (for laptops/desktops)</p>
              <div class="clearfix"></div>
              <hr>
              <div class="clearfix"></div>              
              
            </div>
         </div> 
    </div><!--/articles-->
	    <div class="col-md-3 col-sm-6">
    	<div class="panel panel-default">
           <div class="panel-heading"><a href="#" class="pull-right">View all</a> <h4>Hotel prado</h4></div>
   			<div class="panel-body">
			  <img src="./images/h_prueba.jpg" class="img-responsive img-thumbnail pull-center" style="margin-left:5%; width:90%; height:40%;">
              <div class="clearfix"></div>
			  <hr>
              <p>The more powerful (and 100% fluid) Bootstrap 3 grid now comes in 4 sizes (or "breakpoints"). Tiny (for smartphones), Small (for tablets), Medium (for laptops) and Large (for laptops/desktops)</p>
              <div class="clearfix"></div>
              <hr>
              <div class="clearfix"></div>              
              
            </div>
         </div> 
    </div><!--/articles-->
	    <div class="col-md-3 col-sm-6">
    	<div class="panel panel-default">
           <div class="panel-heading"><a href="#" class="pull-right">View all</a> <h4>Hotel prado</h4></div>
   			<div class="panel-body">
			  <img src="./images/h_prueba.jpg" class="img-responsive img-thumbnail pull-center" style="margin-left:5%; width:90%; height:40%;">
              <div class="clearfix"></div>
			  <hr>
              <p>The more powerful (and 100% fluid) Bootstrap 3 grid now comes in 4 sizes (or "breakpoints"). Tiny (for smartphones), Small (for tablets), Medium (for laptops) and Large (for laptops/desktops)</p>
              <div class="clearfix"></div>
              <hr>
              <div class="clearfix"></div>              
              
            </div>
         </div> 
    </div><!--/articles-->
    </div><!--/articles-->		
</div>	
</div>		
</div>
    </div>
        <div class="clearfix"></div>
	</div><!--/Cuerpo-->
</div><!--/main-->