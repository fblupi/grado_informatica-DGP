<?php
include "BD.php";
$datos = new BD("localhost", "root", "", "GRXDev");
?>
