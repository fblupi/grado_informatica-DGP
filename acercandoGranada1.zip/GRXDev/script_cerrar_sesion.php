<?php

setcookie('sesion_iniciada',false);
setcookie('nombre_perfil','Perfil');
header('location: index.php'); // redirct to certain page now
?>

